/* $Id: lbm.c,v 1.7 2004/05/11 08:45:02 pohlt Exp $ */

/*############################################################################*/

#include "lbm.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include <arm_sve.h>

/*####*/

// Active-lane consolidation
void alc(svbool_t pg, svbool_t p0, svbool_t p1, svuint64_t v0, svuint64_t v1, svuint64_t * idxM, svuint64_t * idxR) {
   svuint64_t t0 = svcompact_u64(p0, v0);
   svuint64_t t1 = svcompact_u64(p1, v1);
   svbool_t n0 = svnot_b_z(svptrue_b64(), p0);
   svuint64_t t2 = svcompact_u64(n0, v0);
   svbool_t n1 = svnot_b_z(pg, p1);
   svuint64_t t3 = svcompact_u64(n1, v1);

   svbool_t cntp1 = svwhilelt_b64_u64(0, svcntp_b64(pg, p1));
   svuint64_t t4 = svsplice_u64(cntp1, t1, t3);
   
   svbool_t cntp0 = svwhilelt_b64_u64(0, svcntp_b64(svptrue_b64(), p0));
   *idxM = svsplice_u64(cntp0, t0, t4);
   
   svbool_t cntpnt0 = svwhilelt_b64_u64(0, svcntp_b64(svptrue_b64(), n0));
   *idxR = svsel_u64(cntpnt0, t2, t4);
}

__attribute((always_inline))
inline void irp (svuint64_t idx, svfloat64_t v0, svfloat64_t v1, svfloat64_t * out) {
   svfloat64_t t0 = svtbl_f64(v0, idx);
   svuint64_t idxa = svsub_n_u64_m(svptrue_b64(), idx, (uint64_t) svcntd());
   svfloat64_t t1 = svtbl_f64(v1, idxa);
   *out = svadd_f64_x(svptrue_b64(), t0, t1);
}

__attribute((always_inline))
inline int none(svbool_t pg, svbool_t p) {
   return !svptest_any(pg, p);
}

__attribute((always_inline))
inline int nonet(svbool_t p) {
   return !svptest_any(svptrue_b64(), p);
}

__attribute((always_inline))
inline int all(svbool_t pg, svbool_t p) {
   return !svptest_any(pg, svnot_b_z(pg, p));
}

__attribute((always_inline))
inline int allt(svbool_t p) {
   return !svptest_any(svptrue_b64(), svnot_b_z(svptrue_b64(), p));
}

__attribute((always_inline))
inline int any(svbool_t pg, svbool_t p) {
   return svptest_any(pg, p);
}

__attribute((always_inline))
inline int anyt(svbool_t p) {
   return svptest_any(svptrue_b64(), p);
}

/*####*/

void print_f64(svfloat64_t v) {
	double buf[32];
	svst1_f64(svptrue_b64(), buf, v);

	for (int i = 0; i < svcntd(); i++) {
		printf("%f ", buf[i]);
	}
	printf("\n");
}

void print_u64(svuint64_t v) {
	uint64_t buf[32];
	svst1_u64(svptrue_b64(), buf, v);

	for (int i = 0; i < svcntd(); i++) {
		printf("%x ", buf[i]);
	}
	printf("\n");
}

void print_bool(svbool_t v) {
	svuint64_t uintbool = svdup_n_u64_z(v, 1);
	uint64_t buf[32];
	svst1_u64(svptrue_b64(), buf, uintbool);

	for (int i = 0; i < svcntd(); i++) {
		printf("%lld ", buf[i]);
	}
	printf("\n");
}

#define SVE_LOAD(pg, idx, adr) svld1_gather_u64index_f64 (pg, adr, idx)
#define SVE_LOAD2(pred, address) svld1_gather_u64base_f64 (pred, address)
#define SVE_STORE(pg, idx, adr, data) svst1_scatter_u64index_f64 (pg, adr, idx, data)
#define SVE_STORE2(pred, base, data) svst1_scatter_u64base_f64 (pred, base, data)

#define DFL1 (1.0/ 3.0)
#define DFL2 (1.0/18.0)
#define DFL3 (1.0/36.0)

__attribute((always_inline))
inline void b1(svbool_t pg, svbool_t pn, svuint64_t idx, double * srcGrid, double * dstGrid) {
	// DST_C_SVE ( dstGrid ) = SRC_C_SVE ( srcGrid, pg, idx );
		svfloat64_t t0 = SVE_LOAD ( pn, idx, SRC_C_ADR(srcGrid) );
		SVE_STORE(pn, idx, DST_C_ADR(dstGrid), t0);

		//DST_S ( dstGrid ) = SRC_N ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_N_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_S_ADR(dstGrid), t0);

		// DST_N ( dstGrid ) = SRC_S ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_S_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_N_ADR(dstGrid), t0);

		// DST_W ( dstGrid ) = SRC_E ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_S_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_W_ADR(dstGrid), t0);

		// DST_E ( dstGrid ) = SRC_W ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_W_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_E_ADR(dstGrid), t0);

		//DST_B ( dstGrid ) = SRC_T ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_T_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_B_ADR(dstGrid), t0);

		//DST_T ( dstGrid ) = SRC_B ( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_B_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_T_ADR(dstGrid), t0);

		//DST_SW( dstGrid ) = SRC_NE( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_NE_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_SW_ADR(dstGrid), t0);
		
		//DST_SE( dstGrid ) = SRC_NW( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_NW_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_SE_ADR(dstGrid), t0);

		//DST_NW( dstGrid ) = SRC_SE( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_SE_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_NW_ADR(dstGrid), t0);

		//DST_NE( dstGrid ) = SRC_SW( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_SW_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_NE_ADR(dstGrid), t0);

		//DST_SB( dstGrid ) = SRC_NT( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_NT_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_SB_ADR(dstGrid), t0);

		//DST_ST( dstGrid ) = SRC_NB( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_NB_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_ST_ADR(dstGrid), t0);

		//DST_NB( dstGrid ) = SRC_ST( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_ST_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_NB_ADR(dstGrid), t0);

		//DST_NT( dstGrid ) = SRC_SB( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_SB_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_NT_ADR(dstGrid), t0);

		//DST_WB( dstGrid ) = SRC_ET( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_ET_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_WB_ADR(dstGrid), t0);

		//DST_WT( dstGrid ) = SRC_EB( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_EB_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_WT_ADR(dstGrid), t0);

		//DST_EB( dstGrid ) = SRC_WT( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_WT_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_EB_ADR(dstGrid), t0);

		//DST_ET( dstGrid ) = SRC_WB( srcGrid );
		t0 = SVE_LOAD (pn, idx, SRC_WB_ADR(srcGrid));
		SVE_STORE(pn, idx, DST_ET_ADR(dstGrid), t0);
}

__attribute((always_inline))
inline void b2(svbool_t pg, svbool_t npn, svuint64_t idx, double * srcGrid, double * dstGrid) {
	/* rho = + SRC_C ( srcGrid ) + SRC_N ( srcGrid )
		+ SRC_S ( srcGrid ) + SRC_E ( srcGrid )
		+ SRC_W ( srcGrid ) + SRC_T ( srcGrid )
		+ SRC_B ( srcGrid ) + SRC_NE( srcGrid )
		+ SRC_NW( srcGrid ) + SRC_SE( srcGrid )
		+ SRC_SW( srcGrid ) + SRC_NT( srcGrid )
		+ SRC_NB( srcGrid ) + SRC_ST( srcGrid )
		+ SRC_SB( srcGrid ) + SRC_ET( srcGrid )
		+ SRC_EB( srcGrid ) + SRC_WT( srcGrid )
		+ SRC_WB( srcGrid ); */
		svfloat64_t t1 = SVE_LOAD(npn, idx, SRC_C_ADR(srcGrid));
		svfloat64_t t2 = SVE_LOAD(npn, idx, SRC_N_ADR(srcGrid));
		svfloat64_t t3 = svadd_f64_m(npn, t1, t2);

		svfloat64_t t4 = SVE_LOAD(npn, idx, SRC_S_ADR(srcGrid));
		svfloat64_t t5 = SVE_LOAD(npn, idx, SRC_E_ADR(srcGrid));
		svfloat64_t t6 = svadd_f64_m(npn, t4, t5);
		svfloat64_t t7 = svadd_f64_m(npn, t3, t6);

		svfloat64_t t8 = SVE_LOAD(npn, idx, SRC_W_ADR(srcGrid));
		svfloat64_t t9 = SVE_LOAD(npn, idx, SRC_T_ADR(srcGrid));
		svfloat64_t t10 = svadd_f64_m(npn, t8, t9);
		svfloat64_t t11 = svadd_f64_m(npn, t7, t10);

		svfloat64_t t12 = SVE_LOAD(npn, idx, SRC_B_ADR(srcGrid));
		svfloat64_t t13 = SVE_LOAD(npn, idx, SRC_NE_ADR(srcGrid));
		svfloat64_t t14 = svadd_f64_m(npn, t12, t13);
		svfloat64_t t15 = svadd_f64_m(npn, t11, t14);

		svfloat64_t t16 = SVE_LOAD(npn, idx, SRC_NW_ADR(srcGrid));
		svfloat64_t t17 = SVE_LOAD(npn, idx, SRC_SE_ADR(srcGrid));
		svfloat64_t t18 = svadd_f64_m(npn, t16, t17);
		svfloat64_t t19 = svadd_f64_m(npn, t15, t18);

		svfloat64_t t20 = SVE_LOAD(npn, idx, SRC_SW_ADR(srcGrid));
		svfloat64_t t21 = SVE_LOAD(npn, idx, SRC_NT_ADR(srcGrid));
		svfloat64_t t22 = svadd_f64_m(npn, t20, t21);
		svfloat64_t t23 = svadd_f64_m(npn, t19, t22);

		svfloat64_t t24 = SVE_LOAD(npn, idx, SRC_NB_ADR(srcGrid));
		svfloat64_t t25 = SVE_LOAD(npn, idx, SRC_ST_ADR(srcGrid));
		svfloat64_t t26 = svadd_f64_m(npn, t24, t25);
		svfloat64_t t27 = svadd_f64_m(npn, t26, t23);

		svfloat64_t t28 = SVE_LOAD(npn, idx, SRC_SB_ADR(srcGrid));
		svfloat64_t t29 = SVE_LOAD(npn, idx, SRC_ET_ADR(srcGrid));
		svfloat64_t t30 = svadd_f64_m(npn, t28, t29);
		svfloat64_t t31 = svadd_f64_m(npn, t30, t27);

		svfloat64_t t32 = SVE_LOAD(npn, idx, SRC_EB_ADR(srcGrid));
		svfloat64_t t33 = SVE_LOAD(npn, idx, SRC_WT_ADR(srcGrid));
		svfloat64_t t34 = svadd_f64_m(npn, t32, t33);
		svfloat64_t t35 = svadd_f64_m(npn, t31, t34);

		svfloat64_t t36 = SVE_LOAD(npn, idx, SRC_WB_ADR(srcGrid));
		svfloat64_t rho_v = svadd_f64_m(npn, t35, t36);

		//ux = + SRC_E ( srcGrid ) - SRC_W ( srcGrid )
		//     + SRC_NE( srcGrid ) - SRC_NW( srcGrid )
		//     + SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		//     + SRC_ET( srcGrid ) + SRC_EB( srcGrid )
		//     - SRC_WT( srcGrid ) - SRC_WB( srcGrid );
		svfloat64_t t38 = SVE_LOAD(npn, idx, SRC_E_ADR(srcGrid));
		svfloat64_t t39 = SVE_LOAD(npn, idx, SRC_W_ADR(srcGrid));
		svfloat64_t t40 = svsub_f64_m(npn, t38, t39);

		svfloat64_t t41 = SVE_LOAD(npn, idx, SRC_NE_ADR(srcGrid));
		svfloat64_t t41_t = svadd_f64_m(npn, t40, t41);
		svfloat64_t t42 = SVE_LOAD(npn, idx, SRC_NW_ADR(srcGrid));
		svfloat64_t t44 = svsub_f64_m(npn, t41_t, t42);
		
		svfloat64_t t45 = SVE_LOAD(npn, idx, SRC_SE_ADR(srcGrid));
		svfloat64_t t45_t = svadd_f64_m(npn, t44, t45);
		svfloat64_t t46 = SVE_LOAD(npn, idx, SRC_SW_ADR(srcGrid));
		svfloat64_t t47 = svsub_f64_m(npn, t45_t, t46);

		svfloat64_t t49 = SVE_LOAD(npn, idx, SRC_ET_ADR(srcGrid));
		svfloat64_t t49_t = svadd_f64_m(npn, t47, t49);
		svfloat64_t t50 = SVE_LOAD(npn, idx, SRC_EB_ADR(srcGrid));
		svfloat64_t t51 = svadd_f64_m(npn, t49_t, t50);

		svfloat64_t t53 = SVE_LOAD(npn, idx, SRC_WT_ADR(srcGrid));
		svfloat64_t t53_t = svsub_f64_m(npn, t51, t53);
		svfloat64_t t54 = SVE_LOAD(npn, idx, SRC_WB_ADR(srcGrid));
		svfloat64_t ux_v = svsub_f64_m(npn, t53_t, t54);

		//uy = + SRC_N ( srcGrid ) - SRC_S ( srcGrid )
		//     + SRC_NE( srcGrid ) + SRC_NW( srcGrid )
		//     - SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		//     + SRC_NT( srcGrid ) + SRC_NB( srcGrid )
		//     - SRC_ST( srcGrid ) - SRC_SB( srcGrid );
		svfloat64_t t57 = SVE_LOAD(npn, idx, SRC_N_ADR(srcGrid));
		svfloat64_t t58 = SVE_LOAD(npn, idx, SRC_S_ADR(srcGrid));
		svfloat64_t t59 = svsub_f64_m(npn, t57, t58);

		svfloat64_t t60 = SVE_LOAD(npn, idx, SRC_NE_ADR(srcGrid));
		svfloat64_t t61 = SVE_LOAD(npn, idx, SRC_NW_ADR(srcGrid));
		svfloat64_t t62 = svadd_f64_m(npn, t59, t60);
		svfloat64_t t63 = svadd_f64_m(npn, t61, t62);
		
		svfloat64_t t64 = SVE_LOAD(npn, idx, SRC_SE_ADR(srcGrid));
		svfloat64_t t65 = SVE_LOAD(npn, idx, SRC_SW_ADR(srcGrid));
		svfloat64_t t66 = svsub_f64_m(npn, t63, t64);
		svfloat64_t t67 = svsub_f64_m(npn, t66, t65);

		svfloat64_t t68 = SVE_LOAD(npn, idx, SRC_NT_ADR(srcGrid));
		svfloat64_t t69 = SVE_LOAD(npn, idx, SRC_NB_ADR(srcGrid));
		svfloat64_t t70 = svadd_f64_m(npn, t67, t68);
		svfloat64_t t71 = svadd_f64_m(npn, t70, t69);

		svfloat64_t t72 = SVE_LOAD(npn, idx, SRC_ST_ADR(srcGrid));
		svfloat64_t t73 = SVE_LOAD(npn, idx, SRC_SB_ADR(srcGrid));
		svfloat64_t t74 = svsub_f64_m(npn, t71, t72);
		svfloat64_t uy_v = svsub_f64_m(npn, t74, t73);
		
		// uz = + SRC_T ( srcGrid ) - SRC_B ( srcGrid )
		//     + SRC_NT( srcGrid ) - SRC_NB( srcGrid )
		//     + SRC_ST( srcGrid ) - SRC_SB( srcGrid )
		//     + SRC_ET( srcGrid ) - SRC_EB( srcGrid )
		//     + SRC_WT( srcGrid ) - SRC_WB( srcGrid );
		svfloat64_t t76 = SVE_LOAD(npn, idx, SRC_T_ADR(srcGrid));
		svfloat64_t t77 = SVE_LOAD(npn, idx, SRC_B_ADR(srcGrid));
		svfloat64_t t78 = svsub_f64_m(npn, t76, t77);

		svfloat64_t t79 = SVE_LOAD(npn, idx, SRC_NT_ADR(srcGrid));
		svfloat64_t t80 = SVE_LOAD(npn, idx, SRC_NB_ADR(srcGrid));
		svfloat64_t t81 = svadd_f64_m(npn, t78, t79);
		svfloat64_t t82 = svsub_f64_m(npn, t81, t80);
		
		svfloat64_t t83 = SVE_LOAD(npn, idx, SRC_ST_ADR(srcGrid));
		svfloat64_t t84 = SVE_LOAD(npn, idx, SRC_SB_ADR(srcGrid));
		svfloat64_t t85 = svadd_f64_m(npn, t82, t83);
		svfloat64_t t86 = svsub_f64_m(npn, t85, t84);

		svfloat64_t t87 = SVE_LOAD(npn, idx, SRC_ET_ADR(srcGrid));
		svfloat64_t t88 = SVE_LOAD(npn, idx, SRC_EB_ADR(srcGrid));
		svfloat64_t t89 = svadd_f64_m(npn, t86, t87);
		svfloat64_t t90 = svsub_f64_m(npn, t89, t88);

		svfloat64_t t91 = SVE_LOAD(npn, idx, SRC_WT_ADR(srcGrid));
		svfloat64_t t92 = SVE_LOAD(npn, idx, SRC_WB_ADR(srcGrid));
		svfloat64_t t93 = svadd_f64_m(npn, t90, t91);
		svfloat64_t uz_v = svsub_f64_z(npn, t93, t92);

		// ux /= rho;
		// uy /= rho;
		// uz /= rho;
		ux_v = svdiv_f64_m(npn, ux_v, rho_v);
		uy_v = svdiv_f64_m(npn, uy_v, rho_v);
		uz_v = svdiv_f64_m(npn, uz_v, rho_v);

		/* if( TEST_FLAG_SWEEP( srcGrid, ACCEL )) {
			ux = 0.005;
			uy = 0.002;
			uz = 0.000;
		} 
		*/
		svuint64_t adr2 = svadd_n_u64_m(npn, svlsl_n_u64_m(svptrue_b64(), idx, 3), TEST_FLAG_SWEEP_ADR(srcGrid));
		//svuint64_t tfs = svld1uw_gather_u64index_u64(pg, , idx);
		svuint64_t tfs2 = svld1uw_gather_u64base_u64(npn, adr2);
		//print_u64(tfs);
		tfs2 = svand_n_u64_m(pg, tfs2, ACCEL);
		svbool_t p2 = svcmpne_n_u64(pg, tfs2, 0);

		ux_v = svdup_n_f64_m(ux_v, p2, 0.005);
		uy_v = svdup_n_f64_m(uy_v, p2, 0.002);
		uz_v = svdup_n_f64_m(uz_v, p2, 0.000);

		//u2 = 1.5 * (ux*ux + uy*uy + uz*uz);
		svfloat64_t t95 = svmul_f64_m(npn, ux_v, ux_v);
		svfloat64_t t96 = svmul_f64_m(npn, uy_v, uy_v);
		svfloat64_t t97 = svadd_f64_m(npn, t95, t96);
		svfloat64_t t98 = svmul_f64_m(npn, uz_v, uz_v);
		svfloat64_t t99 = svadd_f64_m(npn, t97, t98);
		svfloat64_t u2_v = svmul_n_f64_m(npn, t99, 1.5);

		// DST_C ( dstGrid ) = (1.0-OMEGA)*SRC_C ( srcGrid ) + DFL1*OMEGA*rho*(1.0 - u2);
		svfloat64_t t100 = SVE_LOAD(npn, idx, SRC_C_ADR(srcGrid));
		svfloat64_t t101 = svmul_n_f64_m(npn, t100, 1.0-OMEGA);
		svfloat64_t t102 = svmul_n_f64_m(npn, rho_v, DFL1*OMEGA);
		svfloat64_t t102_t = svdup_f64(1.0);
		svfloat64_t t103 = svsub_f64_m(npn, t102_t, u2_v);
		svfloat64_t t104 = svmul_f64_m(npn, t102, t103);
		svfloat64_t t105 = svadd_f64_m(npn, t101, t104);
		SVE_STORE(npn, idx, DST_C_ADR(dstGrid), t105);

		//  DFL2*OMEGA*rho*(1.0 + uy*(4.5*uy + 3.0) - u2)
		svfloat64_t dfl2omegarhov = svmul_n_f64_z(npn, rho_v, DFL2*OMEGA);
		
		svfloat64_t fourfiveuy = svmul_n_f64_m(npn, uy_v, 4.5);
		svfloat64_t fourfiveuypthree = svadd_n_f64_m(npn, fourfiveuy, 3.0);
		svfloat64_t t109 = svmul_f64_m(npn, uy_v, fourfiveuypthree);
		svfloat64_t t110 = svadd_n_f64_m(npn, t109, 1.0);
		svfloat64_t t111 = svsub_f64_m(npn, t110, u2_v);
		svfloat64_t t112 = svmul_f64_m(npn, dfl2omegarhov, t111);

		// DST_N ( dstGrid ) = (1.0-OMEGA)*SRC_N ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       + 3.0) - u2);
		svfloat64_t t114 = SVE_LOAD(npn, idx, SRC_N_ADR(srcGrid));
		svfloat64_t t115 = svmul_n_f64_m(npn, t114, 1.0-OMEGA);
		svfloat64_t t116 = svadd_f64_z(npn, t115, t112);
		SVE_STORE(npn, idx, DST_N_ADR(dstGrid), t116);

		// DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2)
		svfloat64_t fourfiveuysthree = svsub_n_f64_m(npn, fourfiveuy, 3.0);
		svfloat64_t t109_t = svmul_f64_m(npn, uy_v, fourfiveuysthree);
		svfloat64_t t110_t = svadd_n_f64_m(npn, t109_t, 1.0);
		svfloat64_t t111_t = svsub_f64_m(npn, t110_t, u2_v);
		svfloat64_t t112_t = svmul_f64_m(npn, dfl2omegarhov, t111_t);

		// DST_S ( dstGrid ) = (1.0-OMEGA)*SRC_S ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2);
		svfloat64_t t115_t = SVE_LOAD(npn, idx, SRC_S_ADR(srcGrid));
		svfloat64_t t116_t = svmul_n_f64_m(npn, t115_t, 1.0-OMEGA);
		svfloat64_t t117_t = svadd_f64_z(npn, t116_t, t112_t);
		SVE_STORE(npn, idx, DST_S_ADR(dstGrid), t117_t);

		// DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2)
		svfloat64_t fourfiveux = svmul_n_f64_m(npn, ux_v, 4.5);
		svfloat64_t fourfiveuxpthree = svadd_n_f64_m(npn, fourfiveux, 3.0);
		svfloat64_t t121 = svmul_f64_m(npn, ux_v, fourfiveuxpthree);
		svfloat64_t t122 = svadd_n_f64_m(npn, t121, 1.0);
		svfloat64_t t123 = svsub_f64_m(npn, t122, u2_v);
		svfloat64_t t124 = svmul_f64_m(npn, dfl2omegarhov, t123);

		// DST_E ( dstGrid ) = (1.0-OMEGA)*SRC_E ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2);
		svfloat64_t t125 = SVE_LOAD(npn, idx, SRC_E_ADR(srcGrid));
		svfloat64_t t126 = svmul_n_f64_m(npn, t125, 1.0-OMEGA);
		svfloat64_t t127 = svadd_f64_z(npn, t126, t124);
		SVE_STORE(npn, idx, DST_E_ADR(dstGrid), t127);

		// DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2)
		svfloat64_t fourfiveuxsthree = svsub_n_f64_m(npn, fourfiveux, 3.0);
		svfloat64_t t121_t = svmul_f64_m(npn, ux_v, fourfiveuxsthree);
		svfloat64_t t122_t = svadd_n_f64_m(npn, t121_t, 1.0);
		svfloat64_t t123_t = svsub_f64_m(npn, t122_t, u2_v);
		svfloat64_t t124_t = svmul_f64_m(npn, dfl2omegarhov, t123_t);

		// DST_W ( dstGrid ) = (1.0-OMEGA)*SRC_W ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2);
		svfloat64_t t128 = SVE_LOAD(npn, idx, SRC_W_ADR(srcGrid));
		svfloat64_t t129 = svmul_n_f64_m(npn, t128, 1.0-OMEGA);
		svfloat64_t t130 = svadd_f64_m(npn, t129, t124_t);
		SVE_STORE(npn, idx, DST_W_ADR(dstGrid), t130);

		// DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2)
		svfloat64_t fourfiveuz = svmul_n_f64_m(npn, uz_v, 4.5);
		svfloat64_t fourfiveuzpthree = svadd_n_f64_m(npn, fourfiveuz, 3.0);
		svfloat64_t t134 = svmul_f64_m(npn, uz_v, fourfiveuzpthree);
		svfloat64_t t135 = svadd_n_f64_m(npn, t134, 1.0);
		svfloat64_t t136 = svsub_f64_m(npn, t135, u2_v);
		svfloat64_t t137 = svmul_f64_z(npn, dfl2omegarhov, t136);

		// DST_T ( dstGrid ) = (1.0-OMEGA)*SRC_T ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2);
		svfloat64_t t138 = SVE_LOAD(npn, idx, SRC_T_ADR(srcGrid));
		svfloat64_t t139 = svmul_n_f64_m(npn, t138, 1.0-OMEGA);
		svfloat64_t t140 = svadd_f64_z(npn, t139, t137);
		SVE_STORE(npn, idx, DST_T_ADR(dstGrid), t140);

		// DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2)
		svfloat64_t fourfiveuzsthree = svsub_n_f64_m(npn, fourfiveuz, 3.0);
		svfloat64_t t134_t = svmul_f64_m(npn, uz_v, fourfiveuzsthree);
		svfloat64_t t135_t = svadd_n_f64_m(npn, t134_t, 1.0);
		svfloat64_t t136_t = svsub_f64_m(npn, t135_t, u2_v);
		svfloat64_t t137_t = svmul_f64_m(npn, dfl2omegarhov, t136_t);

		// DST_B ( dstGrid ) = (1.0-OMEGA)*SRC_B ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2);
		svfloat64_t t141 = SVE_LOAD(npn, idx, SRC_B_ADR(srcGrid));
		svfloat64_t t142 = svmul_n_f64_m(npn, t141, 1.0-OMEGA);
		svfloat64_t t143 = svadd_f64_z(npn, t142, t137_t);
		SVE_STORE(npn, idx, DST_B_ADR(dstGrid), t143);

		//
		// DFL3*OMEGA*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2)
		svfloat64_t dfl3omegarhov = svmul_n_f64_m(npn, rho_v, DFL3*OMEGA);

		svfloat64_t t145 = svadd_f64_m(npn, ux_v, uy_v);
		svfloat64_t t146 = svmul_n_f64_m(npn, t145, 4.5);
		svfloat64_t t147 = svadd_n_f64_m(npn, t146, 3.0);

		svfloat64_t t148 = svmul_f64_m(npn, t145, t147);
		svfloat64_t t149 = svadd_n_f64_m(npn, t148, 1.0);
		svfloat64_t t150 = svsub_f64_m(npn, t149, u2_v);
		svfloat64_t t151 = svmul_f64_m(npn, dfl3omegarhov, t150);

		// DST_NE( dstGrid ) = (1.0-OMEGA)*SRC_NE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2);
		svfloat64_t t152 = SVE_LOAD(npn, idx, SRC_NE_ADR(srcGrid));
		svfloat64_t t153 = svmul_n_f64_m(npn, t152, 1.0-OMEGA);
		svfloat64_t t154 = svadd_f64_m(npn, t153, t151);
		SVE_STORE(npn, idx, DST_NE_ADR(dstGrid), t154);

		//
		//DFL3*OMEGA*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2)
		svfloat64_t t156 = svadd_f64_m(npn, svneg_f64_z(npn, ux_v), uy_v);
		svfloat64_t t157 = svmul_n_f64_m(npn, t156, 4.5);
		svfloat64_t t158 = svadd_n_f64_m(npn, t157, 3.0);

		svfloat64_t t159 = svmul_f64_m(npn, t156, t158);
		svfloat64_t t160 = svadd_n_f64_m(npn, t159, 1.0);
		svfloat64_t t162 = svsub_f64_m(npn, t160, u2_v);
		svfloat64_t t163 = svmul_f64_m(npn, dfl3omegarhov, t162);

		//DST_NW( dstGrid ) = (1.0-OMEGA)*SRC_NW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2);
		svfloat64_t t164 = SVE_LOAD(npn, idx, SRC_NW_ADR(srcGrid));
		svfloat64_t t165 = svmul_n_f64_m(npn, t164, 1.0-OMEGA);
		svfloat64_t t166 = svadd_f64_m(npn, t165, t163);
		SVE_STORE(npn, idx, DST_NW_ADR(dstGrid), t166);

		//
		// DFL3*OMEGA*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2)
		svfloat64_t t168 = svadd_f64_m(npn, ux_v, svneg_f64_z(npn, uy_v));
		svfloat64_t t169 = svmul_n_f64_m(npn, t168, 4.5);
		svfloat64_t t170 = svadd_n_f64_m(npn, t169, 3.0);

		svfloat64_t t171 = svmul_f64_m(npn, t168, t170);
		svfloat64_t t172 = svadd_n_f64_m(npn, t171, 1.0);
		svfloat64_t t174 = svsub_f64_m(npn, t172, u2_v);
		svfloat64_t t175 = svmul_f64_m(npn, dfl3omegarhov, t174);

		// DST_SE( dstGrid ) = (1.0-OMEGA)*SRC_SE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2);
		svfloat64_t t176 = SVE_LOAD(npn, idx, SRC_SE_ADR(srcGrid));
		svfloat64_t t177 = svmul_n_f64_m(npn, t176, 1.0-OMEGA);
		svfloat64_t t178 = svadd_f64_m(npn, t177, t175);
		SVE_STORE(npn, idx, DST_SE_ADR(dstGrid), t178);

		//
		// DFL3*OMEGA*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2)
		svfloat64_t t180 = svadd_f64_m(npn, svneg_f64_z(npn, uy_v), svneg_f64_z(npn, uy_v));
		svfloat64_t t181 = svmul_n_f64_m(npn, t180, 4.5);
		svfloat64_t t182 = svadd_n_f64_m(npn, t181, 3.0);

		svfloat64_t t183 = svmul_f64_m(npn, t180, t182);
		svfloat64_t t184 = svadd_n_f64_m(npn, t183, 1.0);
		svfloat64_t t186 = svsub_f64_m(npn, t184, u2_v);
		svfloat64_t t187 = svmul_f64_m(npn, dfl3omegarhov, t186);

		//DST_SW( dstGrid ) = (1.0-OMEGA)*SRC_SW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2);
		svfloat64_t t188 = SVE_LOAD(npn, idx, SRC_SW_ADR(srcGrid));
		svfloat64_t t189 = svmul_n_f64_m(npn, t188, 1.0-OMEGA);
		svfloat64_t t190 = svadd_f64_m(npn, t189, t187);
		SVE_STORE(npn, idx, DST_SW_ADR(dstGrid), t190);

		//
		//DFL3*OMEGA*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2)
		svfloat64_t t192 = svadd_f64_m(npn, uy_v, uz_v);
		svfloat64_t t193 = svmul_n_f64_m(npn, t192, 4.5);
		svfloat64_t t194 = svadd_n_f64_m(npn, t193, 3.0);

		svfloat64_t t195 = svmul_f64_m(npn, t192, t194);
		svfloat64_t t196 = svadd_n_f64_m(npn, t195, 1.0);
		svfloat64_t t198 = svsub_f64_m(npn, t196, u2_v);
		svfloat64_t t199 = svmul_f64_m(npn, dfl3omegarhov, t198);

		// DST_NT( dstGrid ) = (1.0-OMEGA)*SRC_NT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2);
		svfloat64_t t200 = SVE_LOAD(npn, idx, SRC_NT_ADR(srcGrid));
		svfloat64_t t201 = svmul_n_f64_m(npn, t200, 1.0-OMEGA);
		svfloat64_t t202 = svadd_f64_m(npn, t201, t199);
		SVE_STORE(npn, idx, DST_NT_ADR(dstGrid), t202);

		//
		// DFL3*OMEGA*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2)
		svfloat64_t t204 = svadd_f64_m(npn, uy_v, svneg_f64_z(npn, uz_v));
		svfloat64_t t205 = svmul_n_f64_m(npn, t204, 4.5);
		svfloat64_t t206 = svadd_n_f64_m(npn, t205, 3.0);

		svfloat64_t t207 = svmul_f64_m(npn, t204, t206);
		svfloat64_t t208 = svadd_n_f64_m(npn, t207, 1.0);
		svfloat64_t t210 = svsub_f64_m(npn, t208, u2_v);
		svfloat64_t t211 = svmul_f64_m(npn, dfl3omegarhov, t210);

		// DST_NB( dstGrid ) = (1.0-OMEGA)*SRC_NB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2);
		svfloat64_t t212 = SVE_LOAD(npn, idx, SRC_NB_ADR(srcGrid));
		svfloat64_t t213 = svmul_n_f64_m(npn, t212, 1.0-OMEGA);
		svfloat64_t t214 = svadd_f64_m(npn, t213, t211);
		SVE_STORE(npn, idx, DST_NB_ADR(dstGrid), t214);

		//
		// DFL3*OMEGA*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2)
		svfloat64_t t216 = svadd_f64_m(npn, svneg_f64_z(npn, uy_v), uz_v);
		svfloat64_t t217 = svmul_n_f64_m(npn, t216, 4.5);
		svfloat64_t t218 = svadd_n_f64_m(npn, t217, 3.0);

		svfloat64_t t219 = svmul_f64_m(npn, t216, t218);
		svfloat64_t t220 = svadd_n_f64_m(npn, t219, 1.0);
		svfloat64_t t222 = svsub_f64_m(npn, t220, u2_v);
		svfloat64_t t223 = svmul_f64_m(npn, dfl3omegarhov, t222);

		// DST_ST( dstGrid ) = (1.0-OMEGA)*SRC_ST( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2);
		svfloat64_t t224 = SVE_LOAD(npn, idx, SRC_ST_ADR(srcGrid));
		svfloat64_t t225 = svmul_n_f64_m(npn, t224, 1.0-OMEGA);
		svfloat64_t t226 = svadd_f64_m(npn, t225, t223);
		SVE_STORE(npn, idx, DST_ST_ADR(dstGrid), t226);

		//
		// DFL3*OMEGA*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2)
		svfloat64_t t228 = svsub_f64_m(npn, svneg_f64_z(npn, uy_v), uz_v);
		svfloat64_t t229 = svmul_n_f64_m(npn, t228, 4.5);
		svfloat64_t t230 = svadd_n_f64_m(npn, t229, 3.0);

		svfloat64_t t231 = svmul_f64_m(npn, t228, t230);
		svfloat64_t t232 = svadd_n_f64_m(npn, t231, 1.0);
		svfloat64_t t234 = svsub_f64_m(npn, t232, u2_v);
		svfloat64_t t235 = svmul_f64_m(npn, dfl3omegarhov, t234);

		//DST_SB( dstGrid ) = (1.0-OMEGA)*SRC_SB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2);
		svfloat64_t t236 = SVE_LOAD(npn, idx, SRC_SB_ADR(srcGrid));
		svfloat64_t t237 = svmul_n_f64_m(npn, t236, 1.0-OMEGA);
		svfloat64_t t238 = svadd_f64_m(npn, t235, t237);
		SVE_STORE(npn, idx, DST_SB_ADR(dstGrid), t238);

		//
		// DFL3*OMEGA*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2)
		svfloat64_t t240 = svadd_f64_m(npn, ux_v, uz_v);
		svfloat64_t t241 = svmul_n_f64_m(npn, t240, 4.5);
		svfloat64_t t242 = svadd_n_f64_m(npn, t229, 3.0);

		svfloat64_t t243 = svmul_f64_m(npn, t240, t242);
		svfloat64_t t244 = svadd_n_f64_m(npn, t243, 1.0);
		svfloat64_t t246 = svsub_f64_m(npn, t244, u2_v);
		svfloat64_t t247 = svmul_f64_m(npn, dfl3omegarhov, t246);

		// DST_ET( dstGrid ) = (1.0-OMEGA)*SRC_ET( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2);
		svfloat64_t t248 = SVE_LOAD(npn, idx, SRC_ET_ADR(srcGrid));
		svfloat64_t t249 = svmul_n_f64_m(npn, t248, 1.0-OMEGA);
		svfloat64_t t250 = svadd_f64_m(npn, t247, t249);
		SVE_STORE(npn, idx, DST_ET_ADR(dstGrid), t250);

		//
		// DFL3*OMEGA*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2)
		svfloat64_t t252 = svadd_f64_m(npn, ux_v, svneg_f64_z(npn, uz_v));
		svfloat64_t t253 = svmul_n_f64_m(npn, t252, 4.5);
		svfloat64_t t254 = svadd_n_f64_m(npn, t253, 3.0);

		svfloat64_t t255 = svmul_f64_m(npn, t252, t254);
		svfloat64_t t256 = svadd_n_f64_m(npn, t255, 1.0);
		svfloat64_t t258 = svsub_f64_m(npn, t256, u2_v);
		svfloat64_t t259 = svmul_f64_m(npn, dfl3omegarhov, t258);

		// DST_EB( dstGrid ) = (1.0-OMEGA)*SRC_EB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2);
		svfloat64_t t260 = SVE_LOAD(npn, idx, SRC_EB_ADR(srcGrid));
		svfloat64_t t261 = svmul_n_f64_m(npn, t260, 1.0-OMEGA);
		svfloat64_t t262 = svadd_f64_m(npn, t259, t261);
		SVE_STORE(npn, idx, DST_EB_ADR(dstGrid), t262);

		//
		// DFL3*OMEGA*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2)
		svfloat64_t t264 = svadd_f64_m(npn, svneg_f64_z(npn, ux_v), uz_v);
		svfloat64_t t265 = svmul_n_f64_m(npn, t264, 4.5);
		svfloat64_t t266 = svadd_n_f64_m(npn, t265, 3.0);

		svfloat64_t t267 = svmul_f64_m(npn, t264, t266);
		svfloat64_t t268 = svadd_n_f64_m(npn, t267, 1.0);
		svfloat64_t t270 = svsub_f64_m(npn, t268, u2_v);
		svfloat64_t t271 = svmul_f64_m(npn, dfl3omegarhov, t270);

		// DST_WT( dstGrid ) = (1.0-OMEGA)*SRC_WT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2);
		svfloat64_t t272 = SVE_LOAD(npn, idx, SRC_WT_ADR(srcGrid));
		svfloat64_t t273 = svmul_n_f64_m(npn, t272, 1.0-OMEGA);
		svfloat64_t t274 = svadd_f64_m(npn, t271, t273);
		SVE_STORE(npn, idx, DST_WT_ADR(dstGrid), t274);

		//
		// DFL3*OMEGA*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2)
		svfloat64_t t276 = svadd_f64_m(npn, svneg_f64_z(npn, ux_v), svneg_f64_z(npn, uz_v));
		svfloat64_t t277 = svmul_n_f64_m(npn, t276, 4.5);
		svfloat64_t t278 = svadd_n_f64_m(npn, t277, 3.0);

		svfloat64_t t279 = svmul_f64_m(npn, t276, t278);
		svfloat64_t t280 = svadd_n_f64_m(npn, t279, 1.0);
		svfloat64_t t281 = svsub_f64_m(npn, t280, u2_v);
		svfloat64_t t282 = svmul_f64_m(npn, dfl3omegarhov, t281);

		// DST_WB( dstGrid ) = (1.0-OMEGA)*SRC_WB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2);
		svfloat64_t t283 = SVE_LOAD(npn, idx, SRC_WB_ADR(srcGrid));
		svfloat64_t t284 = svmul_n_f64_m(npn, t283, 1.0-OMEGA);
		svfloat64_t t285 = svadd_f64_m(npn, t282, t284);
		SVE_STORE(npn, idx, DST_WB_ADR(dstGrid), t285);
}

/*####*/

#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#include <omp.h>
#endif

/*############################################################################*/

#define DFL1 (1.0/ 3.0)
#define DFL2 (1.0/18.0)
#define DFL3 (1.0/36.0)

/*############################################################################*/

void LBM_allocateGrid( double** ptr ) {
	const size_t margin = 2*SIZE_X*SIZE_Y*N_CELL_ENTRIES,
	             size   = sizeof( LBM_Grid ) + 2*margin*sizeof( double );

	*ptr = malloc( size );
	if( ! *ptr ) {
		printf( "LBM_allocateGrid: could not allocate %.1f MByte\n",
		        size / (1024.0*1024.0) );
		exit( 1 );
	}
#ifndef SPEC
	printf( "LBM_allocateGrid: allocated %.1f MByte\n",
	        size / (1024.0*1024.0) );
#endif
	*ptr += margin;
}

/*############################################################################*/

void LBM_freeGrid( double** ptr ) {
	const size_t margin = 2*SIZE_X*SIZE_Y*N_CELL_ENTRIES;

	free( *ptr-margin );
	*ptr = NULL;
}

/*############################################################################*/

void LBM_initializeGrid( LBM_Grid grid ) {
	SWEEP_VAR

	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for
#endif
	SWEEP_START( 0, 0, -2, 0, 0, SIZE_Z+2 )
		LOCAL( grid, C  ) = DFL1;
		LOCAL( grid, N  ) = DFL2;
		LOCAL( grid, S  ) = DFL2;
		LOCAL( grid, E  ) = DFL2;
		LOCAL( grid, W  ) = DFL2;
		LOCAL( grid, T  ) = DFL2;
		LOCAL( grid, B  ) = DFL2;
		LOCAL( grid, NE ) = DFL3;
		LOCAL( grid, NW ) = DFL3;
		LOCAL( grid, SE ) = DFL3;
		LOCAL( grid, SW ) = DFL3;
		LOCAL( grid, NT ) = DFL3;
		LOCAL( grid, NB ) = DFL3;
		LOCAL( grid, ST ) = DFL3;
		LOCAL( grid, SB ) = DFL3;
		LOCAL( grid, ET ) = DFL3;
		LOCAL( grid, EB ) = DFL3;
		LOCAL( grid, WT ) = DFL3;
		LOCAL( grid, WB ) = DFL3;

		CLEAR_ALL_FLAGS_SWEEP( grid );
	SWEEP_END
}

/*############################################################################*/

void LBM_swapGrids( LBM_GridPtr* grid1, LBM_GridPtr* grid2 ) {
	LBM_GridPtr aux = *grid1;
	*grid1 = *grid2;
	*grid2 = aux;
}

/*############################################################################*/

void LBM_loadObstacleFile( LBM_Grid grid, const char* filename ) {
	int x,  y,  z;

	FILE* file = fopen( filename, "rb" );

	for( z = 0; z < SIZE_Z; z++ ) {
		for( y = 0; y < SIZE_Y; y++ ) {
			for( x = 0; x < SIZE_X; x++ ) {
				if( fgetc( file ) != '.' ) SET_FLAG( grid, x, y, z, OBSTACLE );
			}
			fgetc( file );
		}
		fgetc( file );
	}

	fclose( file );
}

/*############################################################################*/

void LBM_initializeSpecialCellsForLDC( LBM_Grid grid ) {
	int x,  y,  z;

	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( x, y )
#endif
	for( z = -2; z < SIZE_Z+2; z++ ) {
		for( y = 0; y < SIZE_Y; y++ ) {
			for( x = 0; x < SIZE_X; x++ ) {
				if( x == 0 || x == SIZE_X-1 ||
				    y == 0 || y == SIZE_Y-1 ||
				    z == 0 || z == SIZE_Z-1 ) {
					SET_FLAG( grid, x, y, z, OBSTACLE );
				}
				else {
					if( (z == 1 || z == SIZE_Z-2) &&
					     x > 1 && x < SIZE_X-2 &&
					     y > 1 && y < SIZE_Y-2 ) {
						SET_FLAG( grid, x, y, z, ACCEL );
					}
				}
			}
		}
	}
}

/*############################################################################*/

void LBM_initializeSpecialCellsForChannel( LBM_Grid grid ) {
	int x,  y,  z;

	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( x, y )
#endif
	for( z = -2; z < SIZE_Z+2; z++ ) {
		for( y = 0; y < SIZE_Y; y++ ) {
			for( x = 0; x < SIZE_X; x++ ) {
				if( x == 0 || x == SIZE_X-1 ||
				    y == 0 || y == SIZE_Y-1 ) {
					SET_FLAG( grid, x, y, z, OBSTACLE );

					if( (z == 0 || z == SIZE_Z-1) &&
					    ! TEST_FLAG( grid, x, y, z, OBSTACLE ))
						SET_FLAG( grid, x, y, z, IN_OUT_FLOW );
				}
			}
		}
	}
}

/*############################################################################*/

void LBM_performStreamCollideBGK( LBM_Grid srcGrid, LBM_Grid dstGrid ) {
	SWEEP_VAR

	double ux, uy, uz, u2, rho;

	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( ux, uy, uz, u2, rho )
#endif


	SWEEP_START( 0, 0, 0, 0, 0, SIZE_Z )
		if( TEST_FLAG_SWEEP( srcGrid, OBSTACLE )) {
			DST_C ( dstGrid ) = SRC_C ( srcGrid );
			DST_S ( dstGrid ) = SRC_N ( srcGrid );
			DST_N ( dstGrid ) = SRC_S ( srcGrid );
			DST_W ( dstGrid ) = SRC_E ( srcGrid );
			DST_E ( dstGrid ) = SRC_W ( srcGrid );
			DST_B ( dstGrid ) = SRC_T ( srcGrid );
			DST_T ( dstGrid ) = SRC_B ( srcGrid );
			DST_SW( dstGrid ) = SRC_NE( srcGrid );
			DST_SE( dstGrid ) = SRC_NW( srcGrid );
			DST_NW( dstGrid ) = SRC_SE( srcGrid );
			DST_NE( dstGrid ) = SRC_SW( srcGrid );
			DST_SB( dstGrid ) = SRC_NT( srcGrid );
			DST_ST( dstGrid ) = SRC_NB( srcGrid );
			DST_NB( dstGrid ) = SRC_ST( srcGrid );
			DST_NT( dstGrid ) = SRC_SB( srcGrid );
			DST_WB( dstGrid ) = SRC_ET( srcGrid );
			DST_WT( dstGrid ) = SRC_EB( srcGrid );
			DST_EB( dstGrid ) = SRC_WT( srcGrid );
			DST_ET( dstGrid ) = SRC_WB( srcGrid );
			continue;
		}

		rho = + SRC_C ( srcGrid ) + SRC_N ( srcGrid )
		      + SRC_S ( srcGrid ) + SRC_E ( srcGrid )
		      + SRC_W ( srcGrid ) + SRC_T ( srcGrid )
		      + SRC_B ( srcGrid ) + SRC_NE( srcGrid )
		      + SRC_NW( srcGrid ) + SRC_SE( srcGrid )
		      + SRC_SW( srcGrid ) + SRC_NT( srcGrid )
		      + SRC_NB( srcGrid ) + SRC_ST( srcGrid )
		      + SRC_SB( srcGrid ) + SRC_ET( srcGrid )
		      + SRC_EB( srcGrid ) + SRC_WT( srcGrid )
		      + SRC_WB( srcGrid );

		ux = + SRC_E ( srcGrid ) - SRC_W ( srcGrid )
		     + SRC_NE( srcGrid ) - SRC_NW( srcGrid )
		     + SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_ET( srcGrid ) + SRC_EB( srcGrid )
		     - SRC_WT( srcGrid ) - SRC_WB( srcGrid );
		uy = + SRC_N ( srcGrid ) - SRC_S ( srcGrid )
		     + SRC_NE( srcGrid ) + SRC_NW( srcGrid )
		     - SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_NT( srcGrid ) + SRC_NB( srcGrid )
		     - SRC_ST( srcGrid ) - SRC_SB( srcGrid );
		uz = + SRC_T ( srcGrid ) - SRC_B ( srcGrid )
		     + SRC_NT( srcGrid ) - SRC_NB( srcGrid )
		     + SRC_ST( srcGrid ) - SRC_SB( srcGrid )
		     + SRC_ET( srcGrid ) - SRC_EB( srcGrid )
		     + SRC_WT( srcGrid ) - SRC_WB( srcGrid );

		ux /= rho;
		uy /= rho;
		uz /= rho;

		if( TEST_FLAG_SWEEP( srcGrid, ACCEL )) {
			ux = 0.005;
			uy = 0.002;
			uz = 0.000;
		}

		u2 = 1.5 * (ux*ux + uy*uy + uz*uz);
		DST_C ( dstGrid ) = (1.0-OMEGA)*SRC_C ( srcGrid ) + DFL1*OMEGA*rho*(1.0                                 - u2);

		DST_N ( dstGrid ) = (1.0-OMEGA)*SRC_N ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       + 3.0) - u2);
		DST_S ( dstGrid ) = (1.0-OMEGA)*SRC_S ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2);
		DST_E ( dstGrid ) = (1.0-OMEGA)*SRC_E ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2);
		DST_W ( dstGrid ) = (1.0-OMEGA)*SRC_W ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2);
		DST_T ( dstGrid ) = (1.0-OMEGA)*SRC_T ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2);
		DST_B ( dstGrid ) = (1.0-OMEGA)*SRC_B ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2);

		DST_NE( dstGrid ) = (1.0-OMEGA)*SRC_NE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2);
		DST_NW( dstGrid ) = (1.0-OMEGA)*SRC_NW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2);
		DST_SE( dstGrid ) = (1.0-OMEGA)*SRC_SE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2);
		DST_SW( dstGrid ) = (1.0-OMEGA)*SRC_SW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2);
		DST_NT( dstGrid ) = (1.0-OMEGA)*SRC_NT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2);
		DST_NB( dstGrid ) = (1.0-OMEGA)*SRC_NB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2);
		DST_ST( dstGrid ) = (1.0-OMEGA)*SRC_ST( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2);
		DST_SB( dstGrid ) = (1.0-OMEGA)*SRC_SB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2);
		DST_ET( dstGrid ) = (1.0-OMEGA)*SRC_ET( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2);
		DST_EB( dstGrid ) = (1.0-OMEGA)*SRC_EB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2);
		DST_WT( dstGrid ) = (1.0-OMEGA)*SRC_WT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2);
		DST_WB( dstGrid ) = (1.0-OMEGA)*SRC_WB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2);
	SWEEP_END
}

void loop(double * srcGrid, double * dstGrid) {
//#define __START_TRACE() { asm volatile (".inst 0x2520e020"); }
  //__START_TRACE();
    //__asm__ volatile("dmb sy\n\torr x3,x3,x3\n":: :"memory");

	SWEEP_START_SVE1( 0, 0, 0, 0, 0, SIZE_Z )

	// TEST_FLAG_SWEEP_SVE IF
	//if( ((*((unsigned int*) ((void*) (&((((srcGrid)[((FLAGS)+N_CELL_ENTRIES*((0)+ (0)*(1*(100))+(0)*(1*(100))*(1*(100))))+(i)]))))))) & (OBSTACLE))) {
	svuint64_t adr = svadd_n_u64_m(pg, svlsl_n_u64_m(svptrue_b64(), idxM, 3), TEST_FLAG_SWEEP_ADR(srcGrid));
	svuint64_t tfs = svld1uw_gather_u64base_u64(pg, adr);
	tfs = svand_n_u64_m(pg, tfs, 1);
	svbool_t pnm = svcmpne_n_u64(pg, tfs, 0);

	SWEEP_START_SVE2( 0, 0, 0, 0, 0, SIZE_Z )

		// TEST_FLAG_SWEEP_SVE IF
		//if( ((*((unsigned int*) ((void*) (&((((srcGrid)[((FLAGS)+N_CELL_ENTRIES*((0)+ (0)*(1*(100))+(0)*(1*(100))*(1*(100))))+(i)]))))))) & (OBSTACLE))) {
		svuint64_t adr2 = svadd_n_u64_m(pg2, svlsl_n_u64_m(svptrue_b64(), idxR, 3), TEST_FLAG_SWEEP_ADR(srcGrid));
		svuint64_t tfs2 = svld1uw_gather_u64base_u64(pg2, adr2);
		tfs2 = svand_n_u64_m(pg2, tfs2, 1);
		svbool_t pnr = svcmpne_n_u64(pg2, tfs2, 0);

		// If none, execute else
		if (none(pg2, pnr)) {
			goto UNI_B2;
		}

		// current vector not empty, ALC
		alc(pg2, pnm, pnr, idxM, idxR, &idxM, &idxR);

		//Recompute pred for idxM, save
		svuint64_t adrm = svadd_n_u64_m(svptrue_b64(), svlsl_n_u64_m(svptrue_b64(), idxM, 3), TEST_FLAG_SWEEP_ADR(srcGrid));
		svuint64_t tfsm = svld1uw_gather_u64base_u64(svptrue_b64(), adrm);
		tfsm = svand_n_u64_m(svptrue_b64(), tfsm, 1);
		pnm = svcmpne_n_u64(svptrue_b64(), tfsm, 0);

		//Recompute pred for idxR
		svuint64_t adrr = svadd_n_u64_m(pg2, svlsl_n_u64_m(svptrue_b64(), idxR, 3), TEST_FLAG_SWEEP_ADR(srcGrid));
		svuint64_t tfsr = svld1uw_gather_u64base_u64(pg2, adrr);
		tfsr = svand_n_u64_m(pg2, tfsr, 1);
		pnr = svcmpne_n_u64(pg2, tfsr, 0);

		/* print_bool(pnm);
		print_bool(pnr);
		printf("\n"); */

		// Recheck remainder vector, remainder vector now empty
		if (none(svptrue_b64(), pnr)) {
			goto UNI_B2;
		}

		// No room for active lanes in merge vector => merge vector full and uniform
		// UNI IF

		UNI_B1:;

		b1(svptrue_b64(), svptrue_b64(), idxM, srcGrid, dstGrid);
		// CONTINUE

		// Set remainder as merge
		idxM = idxR;
		pnm = pnr;

		goto LATCH;

		UNI_B2:;

		svbool_t npnr = svnot_b_z(pg2, pnr);
		b2(pg2, npnr, idxR, srcGrid, dstGrid);

		LATCH:;

		idxS = svadd_n_u64_m(svptrue_b64(), idxS, svcntd()*N_CELL_ENTRIES);
		idxR = idxS;
		pg2 = svcmplt_n_u64(svptrue_b64(), idxR, end);

	SWEEP_END_SVE

	FINAL_M:;

	if (anyt(pnm))
		b1(svptrue_b64(), pnm, idxM, srcGrid, dstGrid);

	svbool_t notpnm = svnot_b_z(svptrue_b64(), pnm);
	if (anyt(notpnm))
		b2(svptrue_b64(), notpnm, idxM, srcGrid, dstGrid);

  __asm__ volatile("dmb sy\n\torr x4,x4,x4\n":: :"memory");
//#define __STOP_TRACE() { asm volatile (".inst 0x2520e040"); }
//  __STOP_TRACE();
}

void LBM_performStreamCollideTRT( LBM_Grid srcGrid, LBM_Grid dstGrid ) {
	SWEEP_VAR

	double ux, uy, uz, u2, rho;

	svfloat64_t rho_v = svdup_n_f64_z(svptrue_b64(), 0);
	svfloat64_t ux_v = svdup_n_f64_z(svptrue_b64(), 0);
	svfloat64_t uy_v = svdup_n_f64_z(svptrue_b64(), 0);
	svfloat64_t uz_v = svdup_n_f64_z(svptrue_b64(), 0);

	const double lambda0 = 1.0/(0.5+3.0/(16.0*(1.0/OMEGA-0.5)));
	double fs[N_CELL_ENTRIES], fa[N_CELL_ENTRIES],
		     feqs[N_CELL_ENTRIES], feqa[N_CELL_ENTRIES];

	/* int count = 0;
	SWEEP_START( 0, 0, 0, 0, 0, SIZE_Z )
		if( TEST_FLAG_SWEEP( srcGrid, OBSTACLE )) {
			DST_C ( dstGrid ) = SRC_C ( srcGrid );
			DST_S ( dstGrid ) = SRC_N ( srcGrid );
			DST_N ( dstGrid ) = SRC_S ( srcGrid );
			DST_W ( dstGrid ) = SRC_E ( srcGrid );
			DST_E ( dstGrid ) = SRC_W ( srcGrid );
			DST_B ( dstGrid ) = SRC_T ( srcGrid );
			DST_T ( dstGrid ) = SRC_B ( srcGrid );
			DST_SW( dstGrid ) = SRC_NE( srcGrid );
			DST_SE( dstGrid ) = SRC_NW( srcGrid );
			DST_NW( dstGrid ) = SRC_SE( srcGrid );
			DST_NE( dstGrid ) = SRC_SW( srcGrid );
			DST_SB( dstGrid ) = SRC_NT( srcGrid );
			DST_ST( dstGrid ) = SRC_NB( srcGrid );
			DST_NB( dstGrid ) = SRC_ST( srcGrid );
			DST_NT( dstGrid ) = SRC_SB( srcGrid );
			DST_WB( dstGrid ) = SRC_ET( srcGrid );
			DST_WT( dstGrid ) = SRC_EB( srcGrid );
			DST_EB( dstGrid ) = SRC_WT( srcGrid );
			DST_ET( dstGrid ) = SRC_WB( srcGrid );
			printf("0 ");
			if (++count == 4) {
				printf("\n");
				count = 0;
			}
			continue;
		}

		rho = + SRC_C ( srcGrid ) + SRC_N ( srcGrid )
		      + SRC_S ( srcGrid ) + SRC_E ( srcGrid )
		      + SRC_W ( srcGrid ) + SRC_T ( srcGrid )
		      + SRC_B ( srcGrid ) + SRC_NE( srcGrid )
		      + SRC_NW( srcGrid ) + SRC_SE( srcGrid )
		      + SRC_SW( srcGrid ) + SRC_NT( srcGrid )
		      + SRC_NB( srcGrid ) + SRC_ST( srcGrid )
		      + SRC_SB( srcGrid ) + SRC_ET( srcGrid )
		      + SRC_EB( srcGrid ) + SRC_WT( srcGrid )
		      + SRC_WB( srcGrid );

		ux = + SRC_E ( srcGrid ) - SRC_W ( srcGrid )
		     + SRC_NE( srcGrid ) - SRC_NW( srcGrid )
		     + SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_ET( srcGrid ) + SRC_EB( srcGrid )
		     - SRC_WT( srcGrid ) - SRC_WB( srcGrid );
		
		uy = + SRC_N ( srcGrid ) - SRC_S ( srcGrid )
		     + SRC_NE( srcGrid ) + SRC_NW( srcGrid )
		     - SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_NT( srcGrid ) + SRC_NB( srcGrid )
		     - SRC_ST( srcGrid ) - SRC_SB( srcGrid );
		
		uz = + SRC_T ( srcGrid ) - SRC_B ( srcGrid )
		     + SRC_NT( srcGrid ) - SRC_NB( srcGrid )
		     + SRC_ST( srcGrid ) - SRC_SB( srcGrid )
		     + SRC_ET( srcGrid ) - SRC_EB( srcGrid )
		     + SRC_WT( srcGrid ) - SRC_WB( srcGrid );

		ux /= rho;
		uy /= rho;
		uz /= rho;

		if( TEST_FLAG_SWEEP( srcGrid, ACCEL )) {
			ux = 0.005;
			uy = 0.002;
			uz = 0.000;
		}

		u2 = 1.5 * (ux*ux + uy*uy + uz*uz);
		DST_C ( dstGrid ) = (1.0-OMEGA)*SRC_C ( srcGrid ) + DFL1*OMEGA*rho*(1.0                                 - u2);

		DST_N ( dstGrid ) = (1.0-OMEGA)*SRC_N ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       + 3.0) - u2);
		DST_S ( dstGrid ) = (1.0-OMEGA)*SRC_S ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2);
		DST_E ( dstGrid ) = (1.0-OMEGA)*SRC_E ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2);
		DST_W ( dstGrid ) = (1.0-OMEGA)*SRC_W ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2);
		DST_T ( dstGrid ) = (1.0-OMEGA)*SRC_T ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2);
		DST_B ( dstGrid ) = (1.0-OMEGA)*SRC_B ( srcGrid ) + DFL2*OMEGA*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2);

		DST_NE( dstGrid ) = (1.0-OMEGA)*SRC_NE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2);
		DST_NW( dstGrid ) = (1.0-OMEGA)*SRC_NW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2);
		DST_SE( dstGrid ) = (1.0-OMEGA)*SRC_SE( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2);
		DST_SW( dstGrid ) = (1.0-OMEGA)*SRC_SW( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2);
		DST_NT( dstGrid ) = (1.0-OMEGA)*SRC_NT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2);
		DST_NB( dstGrid ) = (1.0-OMEGA)*SRC_NB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2);
		DST_ST( dstGrid ) = (1.0-OMEGA)*SRC_ST( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2);
		DST_SB( dstGrid ) = (1.0-OMEGA)*SRC_SB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2);
		DST_ET( dstGrid ) = (1.0-OMEGA)*SRC_ET( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2);
		DST_EB( dstGrid ) = (1.0-OMEGA)*SRC_EB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2);
		DST_WT( dstGrid ) = (1.0-OMEGA)*SRC_WT( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2);
		DST_WB( dstGrid ) = (1.0-OMEGA)*SRC_WB( srcGrid ) + DFL3*OMEGA*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2);

		if (++count == 4) {
			printf("\n");
			count = 0;
		}

	SWEEP_END */

	loop(srcGrid, dstGrid);

	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( ux, uy, uz, u2, rho, fs, fa, feqs, feqa )
#endif
	/* SWEEP_START( 0, 0, 0, 0, 0, SIZE_Z )
		if( TEST_FLAG_SWEEP( srcGrid, OBSTACLE )) {
			DST_C ( dstGrid ) = SRC_C ( srcGrid );
			DST_S ( dstGrid ) = SRC_N ( srcGrid );
			DST_N ( dstGrid ) = SRC_S ( srcGrid );
			DST_W ( dstGrid ) = SRC_E ( srcGrid );
			DST_E ( dstGrid ) = SRC_W ( srcGrid );
			DST_B ( dstGrid ) = SRC_T ( srcGrid );
			DST_T ( dstGrid ) = SRC_B ( srcGrid );
			DST_SW( dstGrid ) = SRC_NE( srcGrid );
			DST_SE( dstGrid ) = SRC_NW( srcGrid );
			DST_NW( dstGrid ) = SRC_SE( srcGrid );
			DST_NE( dstGrid ) = SRC_SW( srcGrid );
			DST_SB( dstGrid ) = SRC_NT( srcGrid );
			DST_ST( dstGrid ) = SRC_NB( srcGrid );
			DST_NB( dstGrid ) = SRC_ST( srcGrid );
			DST_NT( dstGrid ) = SRC_SB( srcGrid );
			DST_WB( dstGrid ) = SRC_ET( srcGrid );
			DST_WT( dstGrid ) = SRC_EB( srcGrid );
			DST_EB( dstGrid ) = SRC_WT( srcGrid );
			DST_ET( dstGrid ) = SRC_WB( srcGrid );
			continue;
		}

		rho = + SRC_C ( srcGrid ) + SRC_N ( srcGrid )
		      + SRC_S ( srcGrid ) + SRC_E ( srcGrid )
		      + SRC_W ( srcGrid ) + SRC_T ( srcGrid )
		      + SRC_B ( srcGrid ) + SRC_NE( srcGrid )
		      + SRC_NW( srcGrid ) + SRC_SE( srcGrid )
		      + SRC_SW( srcGrid ) + SRC_NT( srcGrid )
		      + SRC_NB( srcGrid ) + SRC_ST( srcGrid )
		      + SRC_SB( srcGrid ) + SRC_ET( srcGrid )
		      + SRC_EB( srcGrid ) + SRC_WT( srcGrid )
		      + SRC_WB( srcGrid );

		ux = + SRC_E ( srcGrid ) - SRC_W ( srcGrid )
		     + SRC_NE( srcGrid ) - SRC_NW( srcGrid )
		     + SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_ET( srcGrid ) + SRC_EB( srcGrid )
		     - SRC_WT( srcGrid ) - SRC_WB( srcGrid );
		uy = + SRC_N ( srcGrid ) - SRC_S ( srcGrid )
		     + SRC_NE( srcGrid ) + SRC_NW( srcGrid )
		     - SRC_SE( srcGrid ) - SRC_SW( srcGrid )
		     + SRC_NT( srcGrid ) + SRC_NB( srcGrid )
		     - SRC_ST( srcGrid ) - SRC_SB( srcGrid );
		uz = + SRC_T ( srcGrid ) - SRC_B ( srcGrid )
		     + SRC_NT( srcGrid ) - SRC_NB( srcGrid )
		     + SRC_ST( srcGrid ) - SRC_SB( srcGrid )
		     + SRC_ET( srcGrid ) - SRC_EB( srcGrid )
		     + SRC_WT( srcGrid ) - SRC_WB( srcGrid );

		ux /= rho;
		uy /= rho;
		uz /= rho;

		if( TEST_FLAG_SWEEP( srcGrid, ACCEL )) {
			ux = 0.005;
			uy = 0.002;
			uz = 0.000;
		}

		u2 = 1.5 * (ux*ux + uy*uy + uz*uz);

		feqs[C ] =            DFL1*rho*(1.0                         - u2);
		feqs[N ] = feqs[S ] = DFL2*rho*(1.0 + 4.5*(+uy   )*(+uy   ) - u2);
		feqs[E ] = feqs[W ] = DFL2*rho*(1.0 + 4.5*(+ux   )*(+ux   ) - u2);
		feqs[T ] = feqs[B ] = DFL2*rho*(1.0 + 4.5*(+uz   )*(+uz   ) - u2);
		feqs[NE] = feqs[SW] = DFL3*rho*(1.0 + 4.5*(+ux+uy)*(+ux+uy) - u2);
		feqs[NW] = feqs[SE] = DFL3*rho*(1.0 + 4.5*(-ux+uy)*(-ux+uy) - u2);
		feqs[NT] = feqs[SB] = DFL3*rho*(1.0 + 4.5*(+uy+uz)*(+uy+uz) - u2);
		feqs[NB] = feqs[ST] = DFL3*rho*(1.0 + 4.5*(+uy-uz)*(+uy-uz) - u2);
		feqs[ET] = feqs[WB] = DFL3*rho*(1.0 + 4.5*(+ux+uz)*(+ux+uz) - u2);
		feqs[EB] = feqs[WT] = DFL3*rho*(1.0 + 4.5*(+ux-uz)*(+ux-uz) - u2);

		feqa[C ] = 0.0;
		feqa[S ] = - (feqa[N ] = DFL2*rho*3.0*(+uy   ));
		feqa[W ] = - (feqa[E ] = DFL2*rho*3.0*(+ux   ));
		feqa[B ] = - (feqa[T ] = DFL2*rho*3.0*(+uz   ));
		feqa[SW] = - (feqa[NE] = DFL3*rho*3.0*(+ux+uy));
		feqa[SE] = - (feqa[NW] = DFL3*rho*3.0*(-ux+uy));
		feqa[SB] = - (feqa[NT] = DFL3*rho*3.0*(+uy+uz));
		feqa[ST] = - (feqa[NB] = DFL3*rho*3.0*(+uy-uz));
		feqa[WB] = - (feqa[ET] = DFL3*rho*3.0*(+ux+uz));
		feqa[WT] = - (feqa[EB] = DFL3*rho*3.0*(+ux-uz));

		fs[C ] =                 SRC_C ( srcGrid );
		fs[N ] = fs[S ] = 0.5 * (SRC_N ( srcGrid ) + SRC_S ( srcGrid ));
		fs[E ] = fs[W ] = 0.5 * (SRC_E ( srcGrid ) + SRC_W ( srcGrid ));
		fs[T ] = fs[B ] = 0.5 * (SRC_T ( srcGrid ) + SRC_B ( srcGrid ));
		fs[NE] = fs[SW] = 0.5 * (SRC_NE( srcGrid ) + SRC_SW( srcGrid ));
		fs[NW] = fs[SE] = 0.5 * (SRC_NW( srcGrid ) + SRC_SE( srcGrid ));
		fs[NT] = fs[SB] = 0.5 * (SRC_NT( srcGrid ) + SRC_SB( srcGrid ));
		fs[NB] = fs[ST] = 0.5 * (SRC_NB( srcGrid ) + SRC_ST( srcGrid ));
		fs[ET] = fs[WB] = 0.5 * (SRC_ET( srcGrid ) + SRC_WB( srcGrid ));
		fs[EB] = fs[WT] = 0.5 * (SRC_EB( srcGrid ) + SRC_WT( srcGrid ));

		fa[C ] = 0.0;
		fa[S ] = - (fa[N ] = 0.5 * (SRC_N ( srcGrid ) - SRC_S ( srcGrid )));
		fa[W ] = - (fa[E ] = 0.5 * (SRC_E ( srcGrid ) - SRC_W ( srcGrid )));
		fa[B ] = - (fa[T ] = 0.5 * (SRC_T ( srcGrid ) - SRC_B ( srcGrid )));
		fa[SW] = - (fa[NE] = 0.5 * (SRC_NE( srcGrid ) - SRC_SW( srcGrid )));
		fa[SE] = - (fa[NW] = 0.5 * (SRC_NW( srcGrid ) - SRC_SE( srcGrid )));
		fa[SB] = - (fa[NT] = 0.5 * (SRC_NT( srcGrid ) - SRC_SB( srcGrid )));
		fa[ST] = - (fa[NB] = 0.5 * (SRC_NB( srcGrid ) - SRC_ST( srcGrid )));
		fa[WB] = - (fa[ET] = 0.5 * (SRC_ET( srcGrid ) - SRC_WB( srcGrid )));
		fa[WT] = - (fa[EB] = 0.5 * (SRC_EB( srcGrid ) - SRC_WT( srcGrid )));

		DST_C ( dstGrid ) = SRC_C ( srcGrid ) - OMEGA * (fs[C ] - feqs[C ])                                ;
		DST_N ( dstGrid ) = SRC_N ( srcGrid ) - OMEGA * (fs[N ] - feqs[N ]) - lambda0 * (fa[N ] - feqa[N ]);
		DST_S ( dstGrid ) = SRC_S ( srcGrid ) - OMEGA * (fs[S ] - feqs[S ]) - lambda0 * (fa[S ] - feqa[S ]);
		DST_E ( dstGrid ) = SRC_E ( srcGrid ) - OMEGA * (fs[E ] - feqs[E ]) - lambda0 * (fa[E ] - feqa[E ]);
		DST_W ( dstGrid ) = SRC_W ( srcGrid ) - OMEGA * (fs[W ] - feqs[W ]) - lambda0 * (fa[W ] - feqa[W ]);
		DST_T ( dstGrid ) = SRC_T ( srcGrid ) - OMEGA * (fs[T ] - feqs[T ]) - lambda0 * (fa[T ] - feqa[T ]);
		DST_B ( dstGrid ) = SRC_B ( srcGrid ) - OMEGA * (fs[B ] - feqs[B ]) - lambda0 * (fa[B ] - feqa[B ]);
		DST_NE( dstGrid ) = SRC_NE( srcGrid ) - OMEGA * (fs[NE] - feqs[NE]) - lambda0 * (fa[NE] - feqa[NE]);
		DST_NW( dstGrid ) = SRC_NW( srcGrid ) - OMEGA * (fs[NW] - feqs[NW]) - lambda0 * (fa[NW] - feqa[NW]);
		DST_SE( dstGrid ) = SRC_SE( srcGrid ) - OMEGA * (fs[SE] - feqs[SE]) - lambda0 * (fa[SE] - feqa[SE]);
		DST_SW( dstGrid ) = SRC_SW( srcGrid ) - OMEGA * (fs[SW] - feqs[SW]) - lambda0 * (fa[SW] - feqa[SW]);
		DST_NT( dstGrid ) = SRC_NT( srcGrid ) - OMEGA * (fs[NT] - feqs[NT]) - lambda0 * (fa[NT] - feqa[NT]);
		DST_NB( dstGrid ) = SRC_NB( srcGrid ) - OMEGA * (fs[NB] - feqs[NB]) - lambda0 * (fa[NB] - feqa[NB]);
		DST_ST( dstGrid ) = SRC_ST( srcGrid ) - OMEGA * (fs[ST] - feqs[ST]) - lambda0 * (fa[ST] - feqa[ST]);
		DST_SB( dstGrid ) = SRC_SB( srcGrid ) - OMEGA * (fs[SB] - feqs[SB]) - lambda0 * (fa[SB] - feqa[SB]);
		DST_ET( dstGrid ) = SRC_ET( srcGrid ) - OMEGA * (fs[ET] - feqs[ET]) - lambda0 * (fa[ET] - feqa[ET]);
		DST_EB( dstGrid ) = SRC_EB( srcGrid ) - OMEGA * (fs[EB] - feqs[EB]) - lambda0 * (fa[EB] - feqa[EB]);
		DST_WT( dstGrid ) = SRC_WT( srcGrid ) - OMEGA * (fs[WT] - feqs[WT]) - lambda0 * (fa[WT] - feqa[WT]);
		DST_WB( dstGrid ) = SRC_WB( srcGrid ) - OMEGA * (fs[WB] - feqs[WB]) - lambda0 * (fa[WB] - feqa[WB]);
	SWEEP_END
	*/
}

/*############################################################################*/

void LBM_handleInOutFlow( LBM_Grid srcGrid ) {
	double ux , uy , uz , rho ,
	       ux1, uy1, uz1, rho1,
	       ux2, uy2, uz2, rho2,
	       u2, px, py;
	SWEEP_VAR

	/* inflow */
	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( ux, uy, uz, rho, ux1, uy1, uz1, rho1, \
                                  ux2, uy2, uz2, rho2, u2, px, py )
#endif
	SWEEP_START( 0, 0, 0, 0, 0, 1 )
		rho1 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, C  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, N  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, S  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, E  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, W  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, T  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, B  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, NE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, NW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, SE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, SW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, NT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, NB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, ST )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, SB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, ET )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, EB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, WT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 1, WB );
		rho2 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, C  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, N  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, S  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, E  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, W  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, T  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, B  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, NE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, NW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, SE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, SW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, NT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, NB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, ST )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, SB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, ET )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, EB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, WT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, 2, WB );

		rho = 2.0*rho1 - rho2;

		px = (SWEEP_X / (0.5*(SIZE_X-1))) - 1.0;
		py = (SWEEP_Y / (0.5*(SIZE_Y-1))) - 1.0;
		ux = 0.00;
		uy = 0.00;
		uz = 0.01 * (1.0-px*px) * (1.0-py*py);

		u2 = 1.5 * (ux*ux + uy*uy + uz*uz);

		LOCAL( srcGrid, C ) = DFL1*rho*(1.0                                 - u2);

		LOCAL( srcGrid, N ) = DFL2*rho*(1.0 +       uy*(4.5*uy       + 3.0) - u2);
		LOCAL( srcGrid, S ) = DFL2*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2);
		LOCAL( srcGrid, E ) = DFL2*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2);
		LOCAL( srcGrid, W ) = DFL2*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2);
		LOCAL( srcGrid, T ) = DFL2*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2);
		LOCAL( srcGrid, B ) = DFL2*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2);

		LOCAL( srcGrid, NE) = DFL3*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2);
		LOCAL( srcGrid, NW) = DFL3*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2);
		LOCAL( srcGrid, SE) = DFL3*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2);
		LOCAL( srcGrid, SW) = DFL3*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2);
		LOCAL( srcGrid, NT) = DFL3*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2);
		LOCAL( srcGrid, NB) = DFL3*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2);
		LOCAL( srcGrid, ST) = DFL3*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2);
		LOCAL( srcGrid, SB) = DFL3*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2);
		LOCAL( srcGrid, ET) = DFL3*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2);
		LOCAL( srcGrid, EB) = DFL3*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2);
		LOCAL( srcGrid, WT) = DFL3*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2);
		LOCAL( srcGrid, WB) = DFL3*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2);
	SWEEP_END

	/* outflow */
	/*voption indep*/
#if (defined(_OPENMP) || defined(SPEC_OPENMP)) && !defined(SPEC_SUPPRESS_OPENMP) && !defined(SPEC_AUTO_SUPPRESS_OPENMP)
#pragma omp parallel for private( ux, uy, uz, rho, ux1, uy1, uz1, rho1, \
                                  ux2, uy2, uz2, rho2, u2, px, py )
#endif
	SWEEP_START( 0, 0, SIZE_Z-1, 0, 0, SIZE_Z )
		rho1 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, C  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, N  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, S  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, E  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, W  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, T  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, B  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ST )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ET )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, EB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WB );
		ux1 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, E  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, W  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ET ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, EB )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WB );
		uy1 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, N  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, S  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NE ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NW )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NT ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NB )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ST ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SB );
		uz1 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, T  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, B  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, NB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ST ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, SB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, ET ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, EB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -1, WB );

		ux1 /= rho1;
		uy1 /= rho1;
		uz1 /= rho1;

		rho2 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, C  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, N  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, S  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, E  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, W  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, T  )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, B  ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SE )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SW ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ST )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ET )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, EB ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WT )
		       + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WB );
		ux2 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, E  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, W  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ET ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, EB )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WB );
		uy2 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, N  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, S  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NE ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NW )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SE ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SW )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NT ) + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NB )
		      - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ST ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SB );
		uz2 = + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, T  ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, B  )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, NB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ST ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, SB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, ET ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, EB )
		      + GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WT ) - GRID_ENTRY_SWEEP( srcGrid, 0, 0, -2, WB );

		ux2 /= rho2;
		uy2 /= rho2;
		uz2 /= rho2;

		rho = 1.0;

		ux = 2*ux1 - ux2;
		uy = 2*uy1 - uy2;
		uz = 2*uz1 - uz2;

		u2 = 1.5 * (ux*ux + uy*uy + uz*uz);

		LOCAL( srcGrid, C ) = DFL1*rho*(1.0                                 - u2);

		LOCAL( srcGrid, N ) = DFL2*rho*(1.0 +       uy*(4.5*uy       + 3.0) - u2);
		LOCAL( srcGrid, S ) = DFL2*rho*(1.0 +       uy*(4.5*uy       - 3.0) - u2);
		LOCAL( srcGrid, E ) = DFL2*rho*(1.0 +       ux*(4.5*ux       + 3.0) - u2);
		LOCAL( srcGrid, W ) = DFL2*rho*(1.0 +       ux*(4.5*ux       - 3.0) - u2);
		LOCAL( srcGrid, T ) = DFL2*rho*(1.0 +       uz*(4.5*uz       + 3.0) - u2);
		LOCAL( srcGrid, B ) = DFL2*rho*(1.0 +       uz*(4.5*uz       - 3.0) - u2);

		LOCAL( srcGrid, NE) = DFL3*rho*(1.0 + (+ux+uy)*(4.5*(+ux+uy) + 3.0) - u2);
		LOCAL( srcGrid, NW) = DFL3*rho*(1.0 + (-ux+uy)*(4.5*(-ux+uy) + 3.0) - u2);
		LOCAL( srcGrid, SE) = DFL3*rho*(1.0 + (+ux-uy)*(4.5*(+ux-uy) + 3.0) - u2);
		LOCAL( srcGrid, SW) = DFL3*rho*(1.0 + (-ux-uy)*(4.5*(-ux-uy) + 3.0) - u2);
		LOCAL( srcGrid, NT) = DFL3*rho*(1.0 + (+uy+uz)*(4.5*(+uy+uz) + 3.0) - u2);
		LOCAL( srcGrid, NB) = DFL3*rho*(1.0 + (+uy-uz)*(4.5*(+uy-uz) + 3.0) - u2);
		LOCAL( srcGrid, ST) = DFL3*rho*(1.0 + (-uy+uz)*(4.5*(-uy+uz) + 3.0) - u2);
		LOCAL( srcGrid, SB) = DFL3*rho*(1.0 + (-uy-uz)*(4.5*(-uy-uz) + 3.0) - u2);
		LOCAL( srcGrid, ET) = DFL3*rho*(1.0 + (+ux+uz)*(4.5*(+ux+uz) + 3.0) - u2);
		LOCAL( srcGrid, EB) = DFL3*rho*(1.0 + (+ux-uz)*(4.5*(+ux-uz) + 3.0) - u2);
		LOCAL( srcGrid, WT) = DFL3*rho*(1.0 + (-ux+uz)*(4.5*(-ux+uz) + 3.0) - u2);
		LOCAL( srcGrid, WB) = DFL3*rho*(1.0 + (-ux-uz)*(4.5*(-ux-uz) + 3.0) - u2);
	SWEEP_END
}

/*############################################################################*/

void LBM_showGridStatistics( LBM_Grid grid ) {
	int nObstacleCells = 0,
	    nAccelCells    = 0,
	    nFluidCells    = 0;
	double ux, uy, uz;
	double minU2  = 1e+30, maxU2  = -1e+30, u2;
	double minRho = 1e+30, maxRho = -1e+30, rho;
	double mass = 0;

	SWEEP_VAR

	SWEEP_START( 0, 0, 0, 0, 0, SIZE_Z )
		rho = + LOCAL( grid, C  ) + LOCAL( grid, N  )
		      + LOCAL( grid, S  ) + LOCAL( grid, E  )
		      + LOCAL( grid, W  ) + LOCAL( grid, T  )
		      + LOCAL( grid, B  ) + LOCAL( grid, NE )
		      + LOCAL( grid, NW ) + LOCAL( grid, SE )
		      + LOCAL( grid, SW ) + LOCAL( grid, NT )
		      + LOCAL( grid, NB ) + LOCAL( grid, ST )
		      + LOCAL( grid, SB ) + LOCAL( grid, ET )
		      + LOCAL( grid, EB ) + LOCAL( grid, WT )
		      + LOCAL( grid, WB );
		if( rho < minRho ) minRho = rho;
		if( rho > maxRho ) maxRho = rho;
		mass += rho;

		if( TEST_FLAG_SWEEP( grid, OBSTACLE )) {
			nObstacleCells++;
		}
		else {
			if( TEST_FLAG_SWEEP( grid, ACCEL ))
				nAccelCells++;
			else
				nFluidCells++;

			ux = + LOCAL( grid, E  ) - LOCAL( grid, W  )
			     + LOCAL( grid, NE ) - LOCAL( grid, NW )
			     + LOCAL( grid, SE ) - LOCAL( grid, SW )
			     + LOCAL( grid, ET ) + LOCAL( grid, EB )
			     - LOCAL( grid, WT ) - LOCAL( grid, WB );
			uy = + LOCAL( grid, N  ) - LOCAL( grid, S  )
			     + LOCAL( grid, NE ) + LOCAL( grid, NW )
			     - LOCAL( grid, SE ) - LOCAL( grid, SW )
			     + LOCAL( grid, NT ) + LOCAL( grid, NB )
			     - LOCAL( grid, ST ) - LOCAL( grid, SB );
			uz = + LOCAL( grid, T  ) - LOCAL( grid, B  )
			     + LOCAL( grid, NT ) - LOCAL( grid, NB )
			     + LOCAL( grid, ST ) - LOCAL( grid, SB )
			     + LOCAL( grid, ET ) - LOCAL( grid, EB )
			     + LOCAL( grid, WT ) - LOCAL( grid, WB );
			u2 = (ux*ux + uy*uy + uz*uz) / (rho*rho);
			if( u2 < minU2 ) minU2 = u2;
			if( u2 > maxU2 ) maxU2 = u2;
		}
	SWEEP_END

	printf( "LBM_showGridStatistics:\n"
	        "\tnObstacleCells: %7i nAccelCells: %7i nFluidCells: %7i\n"
	        "\tminRho: %8.6f maxRho: %8.6f Mass: %e\n"
	        "\tminU  : %8.6f maxU  : %8.6f\n\n",
	        nObstacleCells, nAccelCells, nFluidCells,
	        minRho, maxRho, mass,
	        sqrt( minU2 ), sqrt( maxU2 ) );
}

/*############################################################################*/

static void storeValue( FILE* file, OUTPUT_PRECISION* v ) {
	const int litteBigEndianTest = 1;
	if( (*((unsigned char*) &litteBigEndianTest)) == 0 ) {         /* big endian */
		const char* vPtr = (char*) v;
		char buffer[sizeof( OUTPUT_PRECISION )];
#if !defined(SPEC)
		int i;
#else
               size_t i;
#endif

		for (i = 0; i < sizeof( OUTPUT_PRECISION ); i++)
			buffer[i] = vPtr[sizeof( OUTPUT_PRECISION ) - i - 1];

		fwrite( buffer, sizeof( OUTPUT_PRECISION ), 1, file );
	}
	else {                                                     /* little endian */
		fwrite( v, sizeof( OUTPUT_PRECISION ), 1, file );
	}
}

/*############################################################################*/

static void loadValue( FILE* file, OUTPUT_PRECISION* v ) {
	const int litteBigEndianTest = 1;
	if( (*((unsigned char*) &litteBigEndianTest)) == 0 ) {         /* big endian */
		char* vPtr = (char*) v;
		char buffer[sizeof( OUTPUT_PRECISION )];
#if !defined(SPEC)
		int i;
#else
               size_t i;
#endif

		fread( buffer, sizeof( OUTPUT_PRECISION ), 1, file );

		for (i = 0; i < sizeof( OUTPUT_PRECISION ); i++)
			vPtr[i] = buffer[sizeof( OUTPUT_PRECISION ) - i - 1];
	}
	else {                                                     /* little endian */
		fread( v, sizeof( OUTPUT_PRECISION ), 1, file );
	}
}

/*############################################################################*/

void LBM_storeVelocityField( LBM_Grid grid, const char* filename,
                             const int binary ) {
	int x, y, z;
	OUTPUT_PRECISION rho, ux, uy, uz;

	FILE* file = fopen( filename, (binary ? "wb" : "w") );

	for( z = 0; z < SIZE_Z; z++ ) {
		for( y = 0; y < SIZE_Y; y++ ) {
			for( x = 0; x < SIZE_X; x++ ) {
				rho = + GRID_ENTRY( grid, x, y, z, C  ) + GRID_ENTRY( grid, x, y, z, N  )
				      + GRID_ENTRY( grid, x, y, z, S  ) + GRID_ENTRY( grid, x, y, z, E  )
				      + GRID_ENTRY( grid, x, y, z, W  ) + GRID_ENTRY( grid, x, y, z, T  )
				      + GRID_ENTRY( grid, x, y, z, B  ) + GRID_ENTRY( grid, x, y, z, NE )
				      + GRID_ENTRY( grid, x, y, z, NW ) + GRID_ENTRY( grid, x, y, z, SE )
				      + GRID_ENTRY( grid, x, y, z, SW ) + GRID_ENTRY( grid, x, y, z, NT )
				      + GRID_ENTRY( grid, x, y, z, NB ) + GRID_ENTRY( grid, x, y, z, ST )
				      + GRID_ENTRY( grid, x, y, z, SB ) + GRID_ENTRY( grid, x, y, z, ET )
				      + GRID_ENTRY( grid, x, y, z, EB ) + GRID_ENTRY( grid, x, y, z, WT )
				      + GRID_ENTRY( grid, x, y, z, WB );
				ux = + GRID_ENTRY( grid, x, y, z, E  ) - GRID_ENTRY( grid, x, y, z, W  ) 
				     + GRID_ENTRY( grid, x, y, z, NE ) - GRID_ENTRY( grid, x, y, z, NW ) 
				     + GRID_ENTRY( grid, x, y, z, SE ) - GRID_ENTRY( grid, x, y, z, SW ) 
				     + GRID_ENTRY( grid, x, y, z, ET ) + GRID_ENTRY( grid, x, y, z, EB ) 
				     - GRID_ENTRY( grid, x, y, z, WT ) - GRID_ENTRY( grid, x, y, z, WB );
				uy = + GRID_ENTRY( grid, x, y, z, N  ) - GRID_ENTRY( grid, x, y, z, S  ) 
				     + GRID_ENTRY( grid, x, y, z, NE ) + GRID_ENTRY( grid, x, y, z, NW ) 
				     - GRID_ENTRY( grid, x, y, z, SE ) - GRID_ENTRY( grid, x, y, z, SW ) 
				     + GRID_ENTRY( grid, x, y, z, NT ) + GRID_ENTRY( grid, x, y, z, NB ) 
				     - GRID_ENTRY( grid, x, y, z, ST ) - GRID_ENTRY( grid, x, y, z, SB );
				uz = + GRID_ENTRY( grid, x, y, z, T  ) - GRID_ENTRY( grid, x, y, z, B  ) 
				     + GRID_ENTRY( grid, x, y, z, NT ) - GRID_ENTRY( grid, x, y, z, NB ) 
				     + GRID_ENTRY( grid, x, y, z, ST ) - GRID_ENTRY( grid, x, y, z, SB ) 
				     + GRID_ENTRY( grid, x, y, z, ET ) - GRID_ENTRY( grid, x, y, z, EB ) 
				     + GRID_ENTRY( grid, x, y, z, WT ) - GRID_ENTRY( grid, x, y, z, WB );
				ux /= rho;
				uy /= rho;
				uz /= rho;

				if( binary ) {
					/*
					fwrite( &ux, sizeof( ux ), 1, file );
					fwrite( &uy, sizeof( uy ), 1, file );
					fwrite( &uz, sizeof( uz ), 1, file );
					*/
					storeValue( file, &ux );
					storeValue( file, &uy );
					storeValue( file, &uz );
				} else
					fprintf( file, "%e %e %e\n", ux, uy, uz );

			}
		}
	}

	fclose( file );
}

/*############################################################################*/

void LBM_compareVelocityField( LBM_Grid grid, const char* filename,
                             const int binary ) {
	int x, y, z;
	double rho, ux, uy, uz;
	OUTPUT_PRECISION fileUx, fileUy, fileUz,
	                 dUx, dUy, dUz,
	                 diff2, maxDiff2 = -1e+30;

	FILE* file = fopen( filename, (binary ? "rb" : "r") );

	for( z = 0; z < SIZE_Z; z++ ) {
		for( y = 0; y < SIZE_Y; y++ ) {
			for( x = 0; x < SIZE_X; x++ ) {
				rho = + GRID_ENTRY( grid, x, y, z, C  ) + GRID_ENTRY( grid, x, y, z, N  )
				      + GRID_ENTRY( grid, x, y, z, S  ) + GRID_ENTRY( grid, x, y, z, E  )
				      + GRID_ENTRY( grid, x, y, z, W  ) + GRID_ENTRY( grid, x, y, z, T  )
				      + GRID_ENTRY( grid, x, y, z, B  ) + GRID_ENTRY( grid, x, y, z, NE )
				      + GRID_ENTRY( grid, x, y, z, NW ) + GRID_ENTRY( grid, x, y, z, SE )
				      + GRID_ENTRY( grid, x, y, z, SW ) + GRID_ENTRY( grid, x, y, z, NT )
				      + GRID_ENTRY( grid, x, y, z, NB ) + GRID_ENTRY( grid, x, y, z, ST )
				      + GRID_ENTRY( grid, x, y, z, SB ) + GRID_ENTRY( grid, x, y, z, ET )
				      + GRID_ENTRY( grid, x, y, z, EB ) + GRID_ENTRY( grid, x, y, z, WT )
				      + GRID_ENTRY( grid, x, y, z, WB );
				ux = + GRID_ENTRY( grid, x, y, z, E  ) - GRID_ENTRY( grid, x, y, z, W  ) 
				     + GRID_ENTRY( grid, x, y, z, NE ) - GRID_ENTRY( grid, x, y, z, NW ) 
				     + GRID_ENTRY( grid, x, y, z, SE ) - GRID_ENTRY( grid, x, y, z, SW ) 
				     + GRID_ENTRY( grid, x, y, z, ET ) + GRID_ENTRY( grid, x, y, z, EB ) 
				     - GRID_ENTRY( grid, x, y, z, WT ) - GRID_ENTRY( grid, x, y, z, WB );
				uy = + GRID_ENTRY( grid, x, y, z, N  ) - GRID_ENTRY( grid, x, y, z, S  ) 
				     + GRID_ENTRY( grid, x, y, z, NE ) + GRID_ENTRY( grid, x, y, z, NW ) 
				     - GRID_ENTRY( grid, x, y, z, SE ) - GRID_ENTRY( grid, x, y, z, SW ) 
				     + GRID_ENTRY( grid, x, y, z, NT ) + GRID_ENTRY( grid, x, y, z, NB ) 
				     - GRID_ENTRY( grid, x, y, z, ST ) - GRID_ENTRY( grid, x, y, z, SB );
				uz = + GRID_ENTRY( grid, x, y, z, T  ) - GRID_ENTRY( grid, x, y, z, B  ) 
				     + GRID_ENTRY( grid, x, y, z, NT ) - GRID_ENTRY( grid, x, y, z, NB ) 
				     + GRID_ENTRY( grid, x, y, z, ST ) - GRID_ENTRY( grid, x, y, z, SB ) 
				     + GRID_ENTRY( grid, x, y, z, ET ) - GRID_ENTRY( grid, x, y, z, EB ) 
				     + GRID_ENTRY( grid, x, y, z, WT ) - GRID_ENTRY( grid, x, y, z, WB );
				ux /= rho;
				uy /= rho;
				uz /= rho;

				if( binary ) {
					loadValue( file, &fileUx );
					loadValue( file, &fileUy );
					loadValue( file, &fileUz );
				}
				else {
#if !defined(SPEC)
					if( sizeof( OUTPUT_PRECISION ) == sizeof( double )) {
						fscanf( file, "%lf %lf %lf\n", &fileUx, &fileUy, &fileUz );
					}
					else {
#endif
						fscanf( file, "%f %f %f\n", &fileUx, &fileUy, &fileUz );
#if !defined(SPEC)
					}
#endif
				}

				dUx = ux - fileUx;
				dUy = uy - fileUy;
				dUz = uz - fileUz;
				diff2 = dUx*dUx + dUy*dUy + dUz*dUz;
				if( diff2 > maxDiff2 ) maxDiff2 = diff2;
			}
		}
	}

#ifdef SPEC
	printf( "LBM_compareVelocityField: maxDiff = %e  \n\n",
	        sqrt( maxDiff2 )  );
#else
	printf( "LBM_compareVelocityField: maxDiff = %e  ==>  %s\n\n",
	        sqrt( maxDiff2 ),
	        sqrt( maxDiff2 ) > 1e-5 ? "##### ERROR #####" : "OK" );
#endif
	fclose( file );
}
