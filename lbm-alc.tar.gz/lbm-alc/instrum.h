#include <stdint.h>
#include <stdio.h>

uint64_t active =0 ;
uint64_t total = 0;

uint64_t empty=0;
uint64_t quart=0;
uint64_t half=0;
uint64_t threeq=0;
uint64_t fourq=0;
uint64_t full=0;

uint64_t total_iter = 0;

uint64_t reg_block = 0;
uint64_t none_not_taken = 0;

uint64_t cons_block = 0;
uint64_t uni_block = 0;
uint64_t rem_block = 0;
uint64_t rem_none_not_taken;

uint64_t not_initially_empty = 0;
uint64_t not_empty_after_alc = 0;

void count_pred(svbool_t pg, svbool_t p, int mult) {
	double u = svcntp_b64(pg, p) / (double) svcntd();

	if (u == 0)
		empty += mult;
	else if (u <= 0.25)
		quart += mult;
	else if (u <= 0.5)
		half += mult;
	else if (u <= 0.75)
		threeq += mult;
	else if (u < 1)
		fourq += mult;
	else if (u == 1)
		full += mult;
}

void print_stats(void) {
    printf("Active: %lld\n", active);
	printf("Total: %lld\n", total);
	printf("Util: %f\n", active/(double)total);
	printf("\n");
	printf("Uniform: %lld\n", empty+full);
	printf("Divergent: %lld\n", quart+half+threeq+fourq);
	printf("Empty: %lld\n", empty);
	printf("<=25: %lld\n", quart);
	printf("<=50: %lld\n", half);
	printf("<=75: %lld\n", threeq);
	printf("<=100: %lld\n", fourq);
	printf("Full %lld\n", full);
    printf("\nBlock stats:\n");
    printf("Total iter: %lu\n", total_iter);
    printf("Regblock: %lu\n", reg_block);
    printf("\tReg_none_not_taken: %lu\n", none_not_taken);
    printf("Consblock: %lu\n", cons_block);
    printf("\tUniblock: %lu\n", uni_block);
    printf("\tRemblock: %lu\n", rem_block);
    printf("\t\tRem_none_not_taken: %lu\n", rem_none_not_taken);
    printf("not_initially_empty: %lu\n", not_initially_empty);
    printf("not_empty_after_alc: %lu\n", not_empty_after_alc);
}