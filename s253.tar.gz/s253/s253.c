#include <arm_sve.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>

#include "common.h"
#include "array_defs.h"

__attribute__((aligned(ARRAY_ALIGNMENT))) real_t flat_2d_array[LEN_2D*LEN_2D];

__attribute__((aligned(ARRAY_ALIGNMENT))) real_t x[LEN_1D];

__attribute__((aligned(ARRAY_ALIGNMENT))) real_t a[LEN_1D],b[LEN_1D],c[LEN_1D],d[LEN_1D],e[LEN_1D],
                                   aa[LEN_2D][LEN_2D],bb[LEN_2D][LEN_2D],cc[LEN_2D][LEN_2D],tt[LEN_2D][LEN_2D];

__attribute__((aligned(ARRAY_ALIGNMENT))) int indx[LEN_1D];

real_t* __restrict__ xx;
real_t* yy;

#define __START_TRACE() __asm__ volatile("dmb sy\n\torr x3,x3,x3\n":: :"memory")
#define __STOP_TRACE() __asm__ volatile("dmb sy\n\torr x4,x4,x4\n":: :"memory")

int s253(struct args_t * func_args)
{
    initialise_arrays(__func__);
    //__START_TRACE();

    uint64_t vscale = svcntw();
    int32_t * a_ptr = &a[0];
    int32_t * b_ptr = &b[0];
    int32_t * c_ptr = &c[0];
    int32_t * d_ptr = &d[0];
    for (int nl = 0; nl < iterations; nl++) {
        //for (int i = 0; i < LEN_1D; i++) {
        //    if (a[i] > b[i]) {
        //        s = a[i] - b[i] * d[i];
        //        c[i] += s;
        //        a[i] = s;
        //    }
        //}
        svint32_t stepVector = svindex_s32(0, 1);
        svint32_t tripCntVector = svindex_s32(LEN_1D, 0);
        svbool_t AllTrueP = svptrue_b32();
        svbool_t p0 = svcmple_s32(AllTrueP, stepVector, tripCntVector);
        svbool_t p1 = svptrue_b32();
        while (svptest_first(AllTrueP, p0)) {
          // p1 = a[:] > b[:]
          svint32_t a_vec = svld1_gather_s32index_s32(p0, a_ptr, stepVector);
          svint32_t b_vec = svld1_gather_s32index_s32(p0, b_ptr, stepVector);
          p1 = svcmpgt_s32(AllTrueP, a_vec, b_vec);
          // s = a[:] - b[:] * d[:]
          svint32_t d_vec = svld1_gather_s32index_s32(p1, d_ptr, stepVector);
          svint32_t bd_vec = svmul_s32_z(p1, b_vec, d_vec);
          svint32_t s_vec = svsub_s32_z(p1, a_vec, bd_vec);
          // c[:] += s
          svint32_t c_vec = svld1_gather_s32index_s32(p1, c_ptr, stepVector);
          svint32_t new_c_vec = svadd_s32_z(p1, c_vec, s_vec);
          svst1_scatter_s32index_s32(p1, c_ptr, stepVector, new_c_vec);
          // a[:] = s
          svst1_scatter_s32index_s32(p1, a_ptr, stepVector, s_vec);
          // stepVector[:] += vscale
          stepVector = svadd_n_s32_z(AllTrueP, stepVector, vscale);
          p0 = svcmplt_s32(AllTrueP, stepVector, tripCntVector);
        }
        dummy(a, b, c, d, e, aa, bb, cc, 0.);
    }

    //__STOP_TRACE();
    return calc_checksum(__func__);
}

typedef real_t(*test_function_t)(struct args_t *);

void time_function(test_function_t vector_func, void * arg_info)
{
    struct args_t func_args = {.arg_info=arg_info};

    double result = vector_func(&func_args);

    printf("\t%f\n", result);
}


int main(int argc, char ** argv){
    printf("Loop \tChecksum\n");

    time_function((test_function_t)&s253, NULL);
}
